using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ObjectMove  : MonoBehaviour
{
    public Transform target; // 拖入角色 (建议拖入 CharacterRoot)
    public float step = 2f;  // 移动距离

    // 记录初始状态
    private Vector3 startPos;
    private Quaternion startRot;
    private Vector3 startScale;

    void Start()
    {
        // 游戏开始时自动记录
        if (target != null)
        {
            startPos = target.position;
            startRot = target.rotation;
            startScale = target.localScale;
        }
    }

    public void Up()    => target.position += target.forward * step;
    public void Down()  => target.position -= target.forward * step;
    public void Left()  => target.position -= target.right * step;
    public void Right() => target.position += target.right * step;
    
    public void RotateL() => target.rotation *= Quaternion.Euler(0, -10, 0);
    public void RotateR() => target.rotation *= Quaternion.Euler(0, 10, 0);
    
    public void ScaleUp()   => target.localScale += Vector3.one * 0.5f;
    public void ScaleDown() => target.localScale -= Vector3.one * 0.5f;

    // 【新增】复原功能：直接还原到 Start 记录的状态
    public void ResetTransform() 
    {
        if (target == null) return;
        target.position = startPos;
        target.rotation = startRot;
        target.localScale = startScale;
    }
}


